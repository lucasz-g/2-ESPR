package br.com.fiap.restaurante.teste;

import java.util.Map;

import br.com.fiap.restaurante.model.Prato;

public class Teste {
	
	public static void main(String[] args) {
	}

}
