package br.com.fiap.restaurante.model;

import java.util.HashMap;
import java.util.Map;

public class Cardapio {
	
	private Map<Integer, Prato> pratos;
	
	private Map<Integer, Bebida> bebidas;
	
	public Cardapio(Map<Integer, Prato> pratos, Map<Integer, Bebida> bebidas) {
		this.pratos = carregarPratos();
		this.bebidas = carregarBebidas();
	}

	public Map<Integer, Prato> getPratos() {
		return pratos;
	}

	public void setPratos(Map<Integer, Prato> pratos) {
		this.pratos = pratos;
	}

	public Map<Integer, Bebida> getBebidas() {
		return bebidas;
	}

	public void setBebidas(Map<Integer, Bebida> bebidas) {
		this.bebidas = bebidas;
	}
	
	public Map<Integer, Prato> carregarPratos() {
		
		Map<Integer, Prato> pratos = new HashMap<Integer, Prato>();
		return null;
		
	}
	
	public Map<Integer, Bebida> carregarBebidas() {
		
		Map<Integer, Bebida> bebidas = new HashMap<Integer, Bebida>();
		return null;
		
	}

}
